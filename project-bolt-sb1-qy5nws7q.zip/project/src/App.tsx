import React, { useState } from 'react';
import Navbar from './components/Navbar';
import MenuSection from './components/MenuSection';
import { menuItems } from './data/menuItems';
import { MenuCategory } from './types';

function App() {
  const [cartItems, setCartItems] = useState<number[]>([]);

  const handleAddToCart = (itemId: number) => {
    setCartItems([...cartItems, itemId]);
  };

  const categories = Array.from(new Set(menuItems.map(item => item.category))) as MenuCategory[];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar cartCount={cartItems.length} />
      
      {/* Hero Section */}
      <div className="relative pt-16">
        <div className="absolute inset-0">
          <img
            className="w-full h-[500px] object-cover"
            src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1600&q=80"
            alt="Food background"
          />
          <div className="absolute inset-0 bg-gray-900 bg-opacity-50"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
            Delicious Food,
            <br />
            Delivered to You
          </h1>
          <p className="mt-6 text-xl text-gray-100 max-w-3xl">
            Explore our menu of chef-crafted dishes made with fresh, high-quality ingredients.
            Order now for a taste of excellence delivered right to your doorstep.
          </p>
        </div>
      </div>

      {/* Menu Sections */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {categories.map((category) => (
          <MenuSection
            key={category}
            category={category}
            items={menuItems.filter(item => item.category === category)}
            onAddToCart={handleAddToCart}
          />
        ))}
      </div>
    </div>
  );
}

export default App;