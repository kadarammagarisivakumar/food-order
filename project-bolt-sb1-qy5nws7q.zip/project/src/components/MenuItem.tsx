import React from 'react';
import { Plus } from 'lucide-react';

interface MenuItemProps {
  name: string;
  description: string;
  price: number;
  image: string;
  onAddToCart: () => void;
}

export default function MenuItem({ name, description, price, image, onAddToCart }: MenuItemProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
      <img
        src={image}
        alt={name}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-800">{name}</h3>
        <p className="mt-1 text-gray-600 text-sm">{description}</p>
        <div className="mt-4 flex items-center justify-between">
          <span className="text-lg font-bold text-orange-500">₹{price.toFixed(2)}</span>
          <button
            onClick={onAddToCart}
            className="flex items-center gap-1 bg-orange-500 text-white px-3 py-1 rounded-full hover:bg-orange-600 transition-colors"
          >
            <Plus className="h-4 w-4" />
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}