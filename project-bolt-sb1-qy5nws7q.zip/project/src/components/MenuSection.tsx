import React from 'react';
import MenuItem from './MenuItem';
import { MenuCategory } from '../types';

interface MenuSectionProps {
  category: MenuCategory;
  items: Array<{
    id: number;
    name: string;
    description: string;
    price: number;
    image: string;
  }>;
  onAddToCart: (itemId: number) => void;
}

export default function MenuSection({ category, items, onAddToCart }: MenuSectionProps) {
  return (
    <section className="py-8">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">{category}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.map((item) => (
          <MenuItem
            key={item.id}
            {...item}
            onAddToCart={() => onAddToCart(item.id)}
          />
        ))}
      </div>
    </section>
  );
}