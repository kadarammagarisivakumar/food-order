import React from 'react';
import { ShoppingCart, UtensilsCrossed } from 'lucide-react';

export default function Navbar({ cartCount = 0 }: { cartCount?: number }) {
  return (
    <nav className="bg-white shadow-lg fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center">
            <UtensilsCrossed className="h-8 w-8 text-orange-500" />
            <span className="ml-2 text-xl font-bold text-gray-800">FoodieHub</span>
          </div>
          <div className="relative">
            <ShoppingCart className="h-6 w-6 text-gray-600 hover:text-orange-500 cursor-pointer" />
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}