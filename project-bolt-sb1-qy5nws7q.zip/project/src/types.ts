export type MenuCategory = 'Popular' | 'Main Dishes' | 'Sides' | 'Desserts' | 'Beverages';

export interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  category: MenuCategory;
}